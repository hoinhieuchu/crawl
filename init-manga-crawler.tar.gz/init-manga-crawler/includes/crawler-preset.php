<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * AJAX Endpoints for Preset Management
 * File: includes/ajax-presets.php
 */

// AJAX handler for saving presets
add_action( 'wp_ajax_init_manga_save_preset', 'init_manga_ajax_save_preset' );
function init_manga_ajax_save_preset() {
	// Verify nonce
	if ( ! wp_verify_nonce( $_POST['nonce'], 'im_crawler_run' ) ) {
		wp_die( 'Invalid nonce' );
	}

	// Check permissions
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Insufficient permissions' );
	}

	// Get and validate input
	$preset_name = sanitize_text_field( $_POST['preset_name'] );
	$preset_data = json_decode( stripslashes( $_POST['preset_data'] ), true );

	if ( empty( $preset_name ) || empty( $preset_data ) ) {
		wp_send_json_error( 'Invalid preset data' );
	}

	// Sanitize preset data
	$sanitized_data = init_manga_sanitize_preset_data( $preset_data );

	// Get existing presets
	$saved_presets = get_option( 'init_manga_crawler_presets', [] );
	$saved_presets[ $preset_name ] = $sanitized_data;

	// Save to database
	update_option( 'init_manga_crawler_presets', $saved_presets );

	wp_send_json_success( [
		'message' => sprintf( __( 'Preset "%s" saved successfully!', 'init-manga-crawler' ), $preset_name ),
		'presets' => $saved_presets
	] );
}

// AJAX handler for deleting presets
add_action( 'wp_ajax_init_manga_delete_preset', 'init_manga_ajax_delete_preset' );
function init_manga_ajax_delete_preset() {
	// Verify nonce
	if ( ! wp_verify_nonce( $_POST['nonce'], 'im_crawler_run' ) ) {
		wp_die( 'Invalid nonce' );
	}

	// Check permissions
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Insufficient permissions' );
	}

	$preset_name = sanitize_text_field( $_POST['preset_name'] );

	if ( empty( $preset_name ) ) {
		wp_send_json_error( 'Invalid preset name' );
	}

	// Get existing presets
	$saved_presets = get_option( 'init_manga_crawler_presets', [] );
	
	if ( ! isset( $saved_presets[ $preset_name ] ) ) {
		wp_send_json_error( 'Preset not found' );
	}

	unset( $saved_presets[ $preset_name ] );

	// Save to database
	update_option( 'init_manga_crawler_presets', $saved_presets );

	wp_send_json_success( [
		'message' => sprintf( __( 'Preset "%s" deleted successfully!', 'init-manga-crawler' ), $preset_name ),
		'presets' => $saved_presets
	] );
}

// AJAX handler for importing presets
add_action( 'wp_ajax_init_manga_import_presets', 'init_manga_ajax_import_presets' );
function init_manga_ajax_import_presets() {
	// Verify nonce
	if ( ! wp_verify_nonce( $_POST['nonce'], 'im_crawler_run' ) ) {
		wp_die( 'Invalid nonce' );
	}

	// Check permissions
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Insufficient permissions' );
	}

	$presets_data = json_decode( stripslashes( $_POST['presets_data'] ), true );

	if ( empty( $presets_data ) || ! is_array( $presets_data ) ) {
		wp_send_json_error( 'Invalid presets data' );
	}

	// Sanitize all imported presets
	$sanitized_presets = [];

	foreach ( $presets_data as $preset_name => $preset_data ) {
		$preset_name = sanitize_text_field( $preset_name );

		if ( is_array( $preset_data ) ) {
			$sanitized_data = init_manga_sanitize_preset_data( $preset_data );
			$sanitized_presets[ $preset_name ] = $sanitized_data;
		}
	}

	// Save to database
	update_option( 'init_manga_crawler_presets', $sanitized_presets );

	wp_send_json_success( [
		'message' => __( 'Presets imported successfully!', 'init-manga-crawler' ),
		'presets' => $sanitized_presets
	] );
}

/**
 * Helper function to sanitize preset data
 */
function init_manga_sanitize_preset_data( $preset_data ) {
	$sanitized_data = [];
	$allowed_fields = [
		'preprocess_url', 
		'preprocess_selector', 
		'selector_title', 
		'selector_description',
		'selector_author', 
		'selector_genres', 
		'selector_status', 
		'selector_cover',
		'type', 
		'selector_chapters', 
		'selector_content'
	];

	foreach ( $allowed_fields as $field ) {
		if ( isset( $preset_data[ $field ] ) ) {
			$sanitized_data[ $field ] = sanitize_text_field( $preset_data[ $field ] );
		}
	}

	return $sanitized_data;
}
