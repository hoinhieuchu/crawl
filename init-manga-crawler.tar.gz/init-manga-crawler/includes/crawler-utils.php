<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// Lấy HTML từ url
function init_manga_crawler_fetch_html( $url ) {
	if ( empty( $url ) || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
		return new WP_Error( 'invalid_url', __( 'Invalid URL.', 'init-manga-crawler' ) );
	}

	$fake_ip = '192.' . rand(0,255) . '.' . rand(0,255) . '.' . rand(0,255);

	$response = wp_remote_get( $url, [
		'timeout'     => 30, // Tăng timeout
		'redirection' => 10, // Tăng redirection
		'headers'     => [
			'User-Agent'      => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' . rand(100,120) . '.0.' . rand(1000,4999) . '.' . rand(100,199) . ' Safari/537.36',
			'Accept'          => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
			'Accept-Language' => 'en-US,en;q=0.9',
			'Accept-Encoding' => 'gzip, deflate',
			'X-Forwarded-For' => $fake_ip,
			'Client-IP'       => $fake_ip,
			'Referer'         => $url,
		],
	] );

	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$code = wp_remote_retrieve_response_code( $response );
	if ( $code !== 200 ) {
		return new WP_Error( 'http_error', sprintf( __( 'HTTP error: %d', 'init-manga-crawler' ), $code ) );
	}

	$body = wp_remote_retrieve_body( $response );
	if ( empty( $body ) ) {
		return new WP_Error( 'empty_body', __( 'Empty response body.', 'init-manga-crawler' ) );
	}

	return $body;
}

function convert_css_to_xpath( $selector ) {
	$selector = trim( $selector );
	if ( empty( $selector ) ) return '//body';

	// Handle multiple selectors separated by comma
	if ( strpos( $selector, ',' ) !== false ) {
		$selectors = explode( ',', $selector );
		$xpath_parts = [];
		foreach ( $selectors as $sel ) {
			$xpath_parts[] = convert_single_css_to_xpath( trim( $sel ) );
		}
		return implode( ' | ', $xpath_parts );
	}

	return convert_single_css_to_xpath( $selector );
}

function convert_single_css_to_xpath( $selector ) {
	$selector = trim( $selector );
	if ( empty( $selector ) ) return '//body';

	// Handle descendant selectors (space separated)
	$parts = preg_split( '/\s+/', $selector );
	$xpath = '//';

	foreach ( $parts as $part ) {
		if ( empty( $part ) ) continue;
		
		$xpath .= convert_css_part_to_xpath( $part ) . '//';
	}

	return rtrim( $xpath, '//' );
}

function convert_css_part_to_xpath( $part ) {
	// Handle ID selector
	if ( strpos( $part, '#' ) !== false ) {
		$segments = explode( '#', $part );
		$tag = $segments[0] ?: '*';
		$id = $segments[1];
		return $tag . '[@id="' . $id . '"]';
	}

	// Handle class selector
	if ( strpos( $part, '.' ) !== false ) {
		$segments = explode( '.', $part );
		$tag = $segments[0] ?: '*';
		$classes = array_slice( $segments, 1 );
		
		if ( count( $classes ) === 1 ) {
			return $tag . '[contains(concat(" ", normalize-space(@class), " "), " ' . $classes[0] . ' ")]';
		} else {
			// Multiple classes
			$conditions = [];
			foreach ( $classes as $class ) {
				$conditions[] = 'contains(concat(" ", normalize-space(@class), " "), " ' . $class . ' ")';
			}
			return $tag . '[' . implode( ' and ', $conditions ) . ']';
		}
	}

	// Handle attribute selector
	if ( strpos( $part, '[' ) !== false ) {
		preg_match( '/([^[]+)?\[([^\]]+)\]/', $part, $matches );
		$tag = $matches[1] ?: '*';
		$attr = $matches[2];
		
		if ( strpos( $attr, '=' ) !== false ) {
			list( $attr_name, $attr_value ) = explode( '=', $attr, 2 );
			$attr_value = trim( $attr_value, '"\'');
			return $tag . '[@' . $attr_name . '="' . $attr_value . '"]';
		} else {
			return $tag . '[@' . $attr . ']';
		}
	}

	// Just tag name
	return $part;
}

// Kiểm tra có đang dùng theme Init Manga
function init_manga_crawler_is_allowed() {
	// Check theme
	$theme_ok = wp_get_theme()->get_stylesheet() === 'init-manga';

	// Check license function exists + valid
	$license_ok = function_exists( 'init_manga_is_license_valid' ) && init_manga_is_license_valid();

	return $theme_ok && $license_ok;
}

// Lọc bỏ link trong nội dung
add_filter('init_manga_chapter_content', function ($content, $chapter, $manga) {
    if (!$manga || get_post_meta($manga->ID, 'type', true) !== 'novel') {
        return $content;
    }

    $content = wpautop($content);

    $content = preg_replace_callback('/<p\b[^>]*>.*?<\/p>/is', function ($match) {
        return (stripos($match[0], '<a') !== false) ? '' : $match[0];
    }, $content);

    return $content;
}, 10, 3);

// Custom URL validation function - linh hoạt hơn filter_var
function validate_image_url($url) {
    // Kiểm tra cơ bản: có phải http/https không
    if (!preg_match('/^https?:\/\//i', $url)) {
        return false;
    }
    
    // Parse URL
    $parsed = parse_url($url);
    
    // Kiểm tra các thành phần cơ bản
    if (!$parsed || !isset($parsed['host']) || empty($parsed['host'])) {
        return false;
    }
    
    // Kiểm tra host có hợp lệ không (domain hoặc IP)
    if (!filter_var($parsed['host'], FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME) && 
        !filter_var($parsed['host'], FILTER_VALIDATE_IP)) {
        return false;
    }
    
    // Kiểm tra extension ảnh (optional - có thể bỏ nếu muốn linh hoạt hơn)
    $path = $parsed['path'] ?? '';
    $valid_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp'];
    $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    
    // Nếu không có extension hoặc extension không hợp lệ, vẫn cho phép
    // (vì một số site có URL ảnh dynamic không có extension)
    
    return true;
}

// Function để filter content an toàn
function filter_safe_content($html) {
    if (empty($html)) {
        return '';
    }
    
    // Loại bỏ hoàn toàn các thẻ nguy hiểm cùng nội dung bên trong
    $dangerous_tags = [
        'script',
        'style', 
        'iframe',
        'object',
        'embed',
        'form',
        'input',
        'textarea',
        'button',
        'select',
        'option',
        'link',
        'meta',
        'noscript'
    ];
    
    foreach ($dangerous_tags as $tag) {
        // Pattern để remove toàn bộ thẻ và nội dung bên trong (case insensitive)
        $pattern = '/<' . $tag . '\b[^>]*>.*?<\/' . $tag . '>/is';
        $html = preg_replace($pattern, '', $html);
        
        // Remove self-closing tags như <link />, <meta />
        $pattern_self = '/<' . $tag . '\b[^>]*\/?>/i';
        $html = preg_replace($pattern_self, '', $html);
    }
    
    // Loại bỏ các attributes nguy hiểm
    $dangerous_attrs = [
        'onclick',
        'onload', 
        'onerror',
        'onmouseover',
        'onmouseout',
        'onfocus',
        'onblur',
        'onchange',
        'onsubmit',
        'onkeydown',
        'onkeyup',
        'onkeypress',
        'javascript:',
        'vbscript:',
        'data:',
        'style' // Remove inline styles luôn cho an toàn
    ];
    
    foreach ($dangerous_attrs as $attr) {
        if (strpos($attr, ':') !== false) {
            // For javascript:, vbscript:, data: - remove entire attribute value
            $pattern = '/\s+\w+\s*=\s*["\']?' . preg_quote($attr, '/') . '[^"\'>\s]*/i';
        } else {
            // For event handlers and style - remove entire attribute
            $pattern = '/\s+' . preg_quote($attr, '/') . '\s*=\s*["\'][^"\']*["\']?/i';
        }
        $html = preg_replace($pattern, '', $html);
    }
    
    // Làm sạch HTML comments
    $html = preg_replace('/<!--.*?-->/s', '', $html);
    
    // Loại bỏ các khoảng trắng thừa
    $html = preg_replace('/\s+/', ' ', $html);
    $html = trim($html);
    
    return $html;
}

// Tải ảnh - Fixed version với debug
function init_manga_crawler_download_image( $img_url, $post_id ) {
    
    $upload_dir = wp_upload_dir();
    $image_data = wp_remote_get( $img_url, [
        'timeout' => 30,
        'headers' => [
            'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Referer' => '',
        ]
    ]);
    
    if ( is_wp_error( $image_data ) || wp_remote_retrieve_response_code( $image_data ) !== 200 ) {
        $error_msg = is_wp_error( $image_data ) ? $image_data->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $image_data );
        return false;
    }
    
    $image_body = wp_remote_retrieve_body( $image_data );
    $filename = basename( parse_url( $img_url, PHP_URL_PATH ) );
    
    
    // Decode URL encoded characters
    $filename = urldecode( $filename );
    
    // Remove or replace special characters and Vietnamese characters
    $filename = sanitize_file_name( $filename );
    
    // If sanitize_file_name removes too much, create a fallback name
    if ( empty( $filename ) || strlen( $filename ) < 3 ) {
        $filename = 'manga_cover_' . time();
    }
    
    // Ensure we have a proper extension
    $file_extension = pathinfo( $filename, PATHINFO_EXTENSION );
    if ( empty( $file_extension ) ) {
        // Try to detect from content type
        $content_type = wp_remote_retrieve_header( $image_data, 'content-type' );
        
        switch ( $content_type ) {
            case 'image/jpeg':
            case 'image/jpg':
                $filename .= '.jpg';
                break;
            case 'image/png':
                $filename .= '.png';
                break;
            case 'image/gif':
                $filename .= '.gif';
                break;
            case 'image/webp':
                $filename .= '.webp';
                break;
            default:
                $filename .= '.jpg'; // Default fallback
        }
    }
    
    $file_path = $upload_dir['path'] . '/' . $filename;
    $file_url = $upload_dir['url'] . '/' . $filename;
    
    // Ghi file
    if ( file_put_contents( $file_path, $image_body ) ) {
        
        $file_type = wp_check_filetype( $filename );
        
        $attachment = [
            'post_mime_type' => $file_type['type'],
            'post_title'     => sanitize_file_name( pathinfo( $filename, PATHINFO_FILENAME ) ),
            'post_content'   => '',
            'post_status'    => 'inherit'
        ];
        
        $attach_id = wp_insert_attachment( $attachment, $file_path, $post_id );
        
        if ( ! is_wp_error( $attach_id ) ) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $attach_data = wp_generate_attachment_metadata( $attach_id, $file_path );
            wp_update_attachment_metadata( $attach_id, $attach_data );
            
            set_post_thumbnail( $post_id, $attach_id );
            return $file_url;
        }
    }
    
    return false;
}

// Helper function: Enhanced CSS content extraction
function init_manga_crawler_extract_css_content( $content, $doc ) {
    if ( empty( $content ) || ! $doc instanceof DOMDocument ) {
        return $content;
    }
    
    // Tìm tất cả các thẻ style trong document
    $styles = $doc->getElementsByTagName( 'style' );
    $css_rules = array();
    
    // Trích xuất CSS rules từ tất cả các thẻ style
    foreach ( $styles as $style ) {
        $css_content = $style->nodeValue;
        
        // Regex để tìm các CSS rules có dạng .class:before { content: "text"; }
        preg_match_all( '/\.([^:]+):before\s*\{\s*content:\s*["\']([^"\']*)["\'];\s*\}/i', $css_content, $matches, PREG_SET_ORDER );
        
        foreach ( $matches as $match ) {
            $class_name = trim( $match[1] );
            $content_text = $match[2];
            $css_rules[ $class_name ] = $content_text;
        }
    }
    
    // Nếu không tìm thấy CSS rules nào, trả về content gốc
    if ( empty( $css_rules ) ) {
        return $content;
    }
    
    // Tạo DOMDocument mới để xử lý content
    $content_doc = new DOMDocument();
    $content_doc->encoding = 'UTF-8';
    
    // Load content với proper encoding
    $html_content = mb_convert_encoding( $content, 'HTML-ENTITIES', 'UTF-8' );
    @$content_doc->loadHTML( 
        '<?xml encoding="UTF-8">' . $html_content, 
        LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD 
    );
    
    $content_xpath = new DOMXPath( $content_doc );
    
    // Thay thế tất cả các span có class tương ứng
    foreach ( $css_rules as $class_name => $replacement_text ) {
        // Tìm tất cả span có class này
        $spans = $content_xpath->query( "//span[contains(@class, '$class_name')]" );
        
        foreach ( $spans as $span ) {
            // Tạo text node mới
            $text_node = $content_doc->createTextNode( $replacement_text );
            
            // Thay thế span bằng text node
            if ( $span->parentNode ) {
                $span->parentNode->replaceChild( $text_node, $span );
            }
        }
    }
    
    // Lấy nội dung đã được xử lý
    $processed_content = '';
    $body = $content_doc->getElementsByTagName( 'body' )->item( 0 );
    
    if ( $body ) {
        foreach ( $body->childNodes as $child ) {
            $processed_content .= $content_doc->saveHTML( $child );
        }
    } else {
        // Fallback nếu không có body tag
        $processed_content = $content_doc->saveHTML( $content_doc->documentElement );
    }
    
    // Clean up và return
    return trim( $processed_content );
}

// Helper function: Download image with retry for lazy loading
function init_manga_crawler_download_image_retry( $img_url, $post_id, $referer_url ) {
    $retry_count = 3;
    $wait_seconds = 2;
    
    for ( $i = 0; $i < $retry_count; $i++ ) {
        // Wait a bit for lazy loading to potentially resolve
        if ( $i > 0 ) {
            sleep( $wait_seconds );
        }
        
        $args = [
            'timeout' => 30,
            'headers' => [
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept' => 'image/webp,image/apng,image/*,*/*;q=0.8',
                'Referer' => $referer_url,
                'Cache-Control' => 'no-cache',
            ]
        ];
        
        $response = wp_remote_get( $img_url, $args );
        
        if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
            $image_data = wp_remote_retrieve_body( $response );
            $content_type = wp_remote_retrieve_header( $response, 'content-type' );
            
            // Verify it's actually an image
            if ( strpos( $content_type, 'image/' ) === 0 && strlen( $image_data ) > 1000 ) {
                
                $filename = basename( parse_url( $img_url, PHP_URL_PATH ) );
                if ( empty( $filename ) || strpos( $filename, '.' ) === false ) {
                    $ext = '';
                    if ( strpos( $content_type, 'jpeg' ) !== false ) $ext = '.jpg';
                    elseif ( strpos( $content_type, 'png' ) !== false ) $ext = '.png';
                    elseif ( strpos( $content_type, 'webp' ) !== false ) $ext = '.webp';
                    elseif ( strpos( $content_type, 'gif' ) !== false ) $ext = '.gif';
                    
                    $filename = 'cover-' . $post_id . $ext;
                }
                
                $upload = wp_upload_bits( $filename, null, $image_data );
                
                if ( ! $upload['error'] ) {
                    $attachment = [
                        'post_mime_type' => $content_type,
                        'post_title' => sanitize_file_name( $filename ),
                        'post_content' => '',
                        'post_status' => 'inherit'
                    ];
                    
                    $attach_id = wp_insert_attachment( $attachment, $upload['file'], $post_id );
                    
                    if ( ! is_wp_error( $attach_id ) ) {
                        require_once ABSPATH . 'wp-admin/includes/image.php';
                        $attach_data = wp_generate_attachment_metadata( $attach_id, $upload['file'] );
                        wp_update_attachment_metadata( $attach_id, $attach_data );
                        set_post_thumbnail( $post_id, $attach_id );
                        return $attach_id;
                    }
                }
            }
        }
    }
    
    return false;
}

// Helper: HTML entities decode
function fully_decode_html($input, $strip_tags = false, $max_iterations = 20) {
    $prev = '';
    $i = 0;

    while ($input !== $prev && $i < $max_iterations) {
        $prev = $input;
        $input = html_entity_decode($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $i++;
    }

    if ($strip_tags) {
        $input = wp_strip_all_tags($input);
    }

    return $input;
}
