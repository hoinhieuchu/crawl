<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// Ajax
add_action( 'wp_ajax_init_manga_crawler_extract_links', 'init_manga_crawler_extract_links' );
add_action( 'wp_ajax_init_manga_crawler_run', 'init_manga_crawler_run' );
add_action( 'wp_ajax_init_manga_crawler_add_chapter', 'init_manga_crawler_add_chapter' );

// Lấy các url truyện từ tranh danh sách
function init_manga_crawler_extract_links() {
	$url      = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
	$selector = isset($_POST['selector']) ? sanitize_text_field($_POST['selector']) : '';

	if (empty($url) || empty($selector)) {
		wp_send_json_error(['message' => __('Missing URL or selector.', 'init-manga-crawler')]);
	}

	$html = init_manga_crawler_fetch_html($url);
	if (is_wp_error($html)) {
		wp_send_json_error(['message' => $html->get_error_message()]);
	}

	libxml_use_internal_errors(true);
	$dom = new DOMDocument();
	@$dom->loadHTML($html);
	$xpath = new DOMXPath($dom);

	$xpath_query = convert_css_to_xpath($selector);
	$nodes = $xpath->query($xpath_query);

	if (!$nodes || $nodes->length === 0) {
		wp_send_json_error(['message' => __('No links found using the given selector.', 'init-manga-crawler')]);
	}

	$urls = [];
	foreach ($nodes as $node) {
		if ($node->hasAttribute('href')) {
			$href = trim($node->getAttribute('href'));
			if (!empty($href)) {
				$href = esc_url_raw($href);
				$urls[] = $href;

				if (strpos($href, 'vivutruyen.net') !== false) {
					$clone = str_replace('vivutruyen.net', 'vivutruyen2.net', $href);
					$urls[] = esc_url_raw($clone);
				} elseif (strpos($href, 'vivutruyen2.net') !== false) {
					$clone = str_replace('vivutruyen2.net', 'vivutruyen.net', $href);
					$urls[] = esc_url_raw($clone);
				}
			}
		}
	}

	$urls = array_unique($urls);

	wp_send_json_success(['urls' => $urls]);
}

// Thêm truyện mới - Fixed version
function init_manga_crawler_run() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( [ 'message' => 'Permission denied.' ] );
	}
	check_ajax_referer( 'im_crawler_run', 'nonce' );

	$url          	  = esc_url_raw( $_POST['crawl_link'] ?? '' );
	// $type         	  = sanitize_text_field( $_POST['type'] ?? 'novel' );
	$type 			  = 'novel';
	$title_sel    	  = sanitize_text_field( $_POST['selector_title'] ?? '' );
	$desc_sel     	  = sanitize_text_field( $_POST['selector_description'] ?? '' );
	$author_sel   	  = sanitize_text_field( $_POST['selector_author'] ?? '' );
	$genres_sel   	  = sanitize_text_field( $_POST['selector_genres'] ?? '' );
	$status_sel   	  = sanitize_text_field( $_POST['selector_status'] ?? '' );
	$chapters_sel 	  = sanitize_text_field( $_POST['selector_chapters'] ?? '' );
	$content_selector = sanitize_text_field( $_POST['selector_content'] ?? '' );

	if ( empty( $url ) || empty( $title_sel ) || empty( $chapters_sel ) ) {
		wp_send_json_error( [ 'message' => 'Missing required selectors.' ] );
	}

	$html = init_manga_crawler_fetch_html( $url );
	if ( is_wp_error( $html ) ) {
		wp_send_json_error( [ 'message' => $html->get_error_message() ] );
	}

	// Kiểm tra xem HTML có dữ liệu không
	if ( strlen( $html ) < 100 ) {
		wp_send_json_error( [ 'message' => 'HTML response too short, possible blocking.' ] );
	}

	libxml_use_internal_errors( true );
	$doc = new DOMDocument();
	
	// Thêm mb_convert_encoding để handle encoding
	$html = mb_convert_encoding( $html, 'HTML-ENTITIES', 'UTF-8' );
	
	$loaded = @$doc->loadHTML( $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	if ( ! $loaded ) {
		$errors = libxml_get_errors();
		// Vẫn tiếp tục vì loadHTML có thể parse được dù có lỗi
	}
	
	$xpath = new DOMXPath( $doc );

	$get_text = function( $selector ) use ( $xpath ) {
		if ( empty( $selector ) ) return '';
		
		$xpath_query = convert_css_to_xpath( $selector );
		
		$elements = @$xpath->query( $xpath_query );
		if ( $elements && $elements->length > 0 ) {
			$text = trim( $elements->item(0)->textContent );
			return $text;
		}
		
		return '';
	};

	$get_text_multi = function( $selector ) use ( $xpath ) {
		if ( empty( $selector ) ) return [];
		
		$xpath_query = convert_css_to_xpath( $selector );
		
		$elements = @$xpath->query( $xpath_query );
		$list = [];
		if ( $elements && $elements->length > 0 ) {
			foreach ( $elements as $el ) {
				$text = trim( $el->textContent );
				if ( ! empty( $text ) ) {
					$list[] = $text;
				}
			}
		}
		
		return $list;
	};

	$get_links = function( $selector ) use ( $xpath, $url ) {
		if ( empty( $selector ) ) return [];
		
		$xpath_query = convert_css_to_xpath( $selector );
		
		$elements = @$xpath->query( $xpath_query );
		$list = [];
		
		if ( $elements && $elements->length > 0 ) {
			
			foreach ( $elements as $el ) {
				$href = $el->getAttribute('href');
				$text = trim( $el->textContent );
				
				if ( ! empty( $href ) && ! empty( $text ) ) {
					// Convert relative URLs to absolute
					if ( ! filter_var( $href, FILTER_VALIDATE_URL ) ) {
						$base_url = rtrim( $url, '/' );
						if ( strpos( $href, '/' ) === 0 ) {
							$parsed = parse_url( $base_url );
							$href = $parsed['scheme'] . '://' . $parsed['host'] . $href;
						} else {
							$href = $base_url . '/' . ltrim( $href, '/' );
						}
					}
					
					$list[] = [
						'name' => $text,
						'url'  => esc_url_raw( $href ),
					];
				}
			}
		}
		
		return $list;
	};

	$get_text_multi_xpath = function( $xpath_query ) use ( $xpath ) {
        if ( empty( $xpath_query ) ) return [];

        $elements = @$xpath->query( $xpath_query );
        $list = [];
        if ( $elements && $elements->length > 0 ) {
            foreach ( $elements as $el ) {
                $text = trim( $el->textContent );
                if ( ! empty( $text ) ) {
                    $list[] = $text;
                }
            }
        }
        return $list;
    };

	// Get & format data
	$post_title_raw = $get_text( $title_sel );
	$post_title = mb_convert_case( $post_title_raw, MB_CASE_TITLE, "UTF-8" );
	$post_content_raw = $get_text( $desc_sel );
	$post_content = filter_safe_content( $post_content_raw );

	if ( empty( $post_title ) ) {
		wp_send_json_error( [ 'message' => 'Title not found. Check title selector.' ] );
	}

	// Xử lý status từ selector
	$final_status = 'ongoing'; // Mặc định
	
	if ( ! empty( $status_sel ) ) {
		$status_text = strtolower( $get_text( $status_sel ) );
		
		// Kiểm tra các từ khóa hoàn thành
		$completed_keywords = ['full', 'hoàn thành', 'trọn bộ', 'completed', 'finished', 'end'];
		
		foreach ( $completed_keywords as $keyword ) {
			if ( strpos( $status_text, $keyword ) !== false ) {
				$final_status = 'completed';
				break;
			}
		}
	}

	// Check if post already exists - Fixed deprecated get_page_by_title
	$query = new WP_Query([
		'post_type'      => 'manga',
		'post_status'    => 'any',
		'posts_per_page' => 1,
		'title'          => $post_title,
	]);
	
	$exists = null;
	if ( $query->have_posts() ) {
		$exists = $query->posts[0];
	}
	wp_reset_postdata();
	
	$meta_data = [
	    '_imc_crawl_url'         => $url,
	    '_imc_selector_chapters' => $chapters_sel,
	    '_imc_selector_content'	 => $content_selector,
	];
	
	if ( $exists && $exists->ID ) {
		// Update type cho existing post
		update_post_meta( $exists->ID, 'type', $type );
		// Update status với giá trị mới được phát hiện
		update_post_meta( $exists->ID, 'status', $final_status );

		foreach ( $meta_data as $key => $val ) {
		    $current = get_post_meta( $exists->ID, $key, true );
		    if ( $current !== $val ) {
		        update_post_meta( $exists->ID, $key, $val );
		    }
		}
		
		$chapters = $get_links( $chapters_sel );
		
		return wp_send_json_success([
			'post_id'  => $exists->ID,
			'title'    => $post_title,
			'chapters' => $chapters,
			'status'   => $final_status,
			'note'     => 'Manga already exists, returning existing post.',
		]);
	}

	// Insert manga
	$post_id = wp_insert_post([
		'post_type'    => 'manga',
		'post_title'   => $post_title,
		'post_content' => $post_content,
		'post_status'  => 'publish',
	]);

	foreach ( $meta_data as $key => $val ) {
	    update_post_meta( $post_id, $key, $val );
	}

	if ( is_wp_error( $post_id ) || ! $post_id ) {
		wp_send_json_error( [ 'message' => 'Failed to create manga post.' ] );
	}

	// Sử dụng $final_status thay vì $status cứng
	update_post_meta( $post_id, 'status', $final_status );
	update_post_meta( $post_id, 'type', $type );

	// Handle taxonomy: genres
	$genres = $get_text_multi( $genres_sel );
	if ( empty( $genres ) ) {
		// Fallback: Tìm thẻ <a> trong <li> có <b> chứa chữ "Thể Loại"
		$genres = $get_text_multi_xpath( "//li[contains(b, 'Thể Loại')]/a" );
	}

	if ( ! empty( $genres ) ) {
		$genre_term_ids = [];
        foreach ( $genres as $genre_name ) {
            $term = term_exists( $genre_name, 'genre' );
            if ( $term !== 0 && $term !== null ) {
                $genre_term_ids[] = (int) $term['term_id'];
            } else {
                $new_term = wp_insert_term( $genre_name, 'genre' );
                if ( ! is_wp_error( $new_term ) ) {
                    $genre_term_ids[] = (int) $new_term['term_id'];
                }
            }
        }
        if( !empty($genre_term_ids) ) {
            wp_set_post_terms( $post_id, $genre_term_ids, 'genre' );
        }
	}

	// Handle taxonomy: authors
	$authors = $get_text_multi( $author_sel );
	if ( empty( $authors ) ) {
		// Fallback 1: Tìm tác giả trong thẻ <a>
		$authors = $get_text_multi_xpath( "//li[contains(b, 'Tác giả')]/a" );

        // Fallback 2: Nếu không có thẻ <a>, thử lấy text thường bên cạnh
        if ( empty($authors) ) {
            $authors = $get_text_multi_xpath("//li[contains(b, 'Tác giả')]/text()[normalize-space()]");
        }
	}

	if ( ! empty( $authors ) ) {
        $author_term_ids = [];
		foreach ( $authors as $author_name ) {
			$term = term_exists( $author_name, 'author_tax' );
            if ( $term !== 0 && $term !== null ) {
                $author_term_ids[] = (int) $term['term_id'];
            } else {
                $new_term = wp_insert_term( $author_name, 'author_tax' );
                if( ! is_wp_error($new_term) ) {
                    $author_term_ids[] = (int) $new_term['term_id'];
                }
            }
		}
        if( !empty($author_term_ids) ) {
		    wp_set_post_terms( $post_id, $author_term_ids, 'author_tax' );
        }
	}

	// Parse chapter links
	$chapters = $get_links( $chapters_sel );
	if ( empty( $chapters ) ) {
		wp_send_json_error( [ 'message' => 'No chapters found. Check chapter selector or try different selector.' ] );
	}

	// UPGRADED: Enhanced cover image parsing with better lazyload support
	$cover_sel = sanitize_text_field( $_POST['selector_cover'] ?? '' );
	if ( $cover_sel ) {
	    $cover_xpath = convert_css_to_xpath( $cover_sel );
	    $cover_els = @$xpath->query( $cover_xpath );

	    if ( $cover_els && $cover_els->length > 0 ) {
	        $img_element = $cover_els->item(0);
	        
	        // PRIORITY ORDER: Ưu tiên các thuộc tính lazyload trước
	        $img_url = '';
	        $lazyload_attributes = [
	            'data-src',           // Lazyload phổ biến nhất
	            'data-lazy-src',      // Lazy load plugin
	            'data-original',      // Some lazy libraries
	            'data-srcset',        // Responsive lazyload
	            'data-bg',           // Background image lazyload
	            'data-thumb',        // Thumbnail lazyload
	            'data-img',          // Custom data attribute
	            'data-image-src',    // Another common pattern
	        ];
	        
	        $standard_attributes = [
	            'src',               // Standard src (cuối cùng mới check)
	        ];
	        
	        // 1. Ưu tiên check lazyload attributes trước
	        foreach ( $lazyload_attributes as $attr ) {
	            $img_url = $img_element->getAttribute( $attr );
	            if ( ! empty( $img_url ) && validate_image_url( $img_url ) ) {
	                break; // Tìm được URL hợp lệ từ lazyload
	            }
	        }
	        
	        // 2. Nếu chưa có, mới check standard src
	        if ( empty( $img_url ) ) {
	            foreach ( $standard_attributes as $attr ) {
	                $img_url = $img_element->getAttribute( $attr );
	                if ( ! empty( $img_url ) ) {
	                    break;
	                }
	            }
	        }
	        
	        // 3. Fallback: Thử lấy từ style background-image
	        if ( empty( $img_url ) ) {
	            $style = $img_element->getAttribute( 'style' );
	            if ( preg_match( '/background-image:\s*url\(["\']?([^"\']+)["\']?\)/i', $style, $matches ) ) {
	                $img_url = $matches[1];
	            }
	        }
	        
	        // 4. Fallback cuối: Check parent elements cho background image
	        if ( empty( $img_url ) && $img_element->parentNode ) {
	            $parent_style = $img_element->parentNode->getAttribute( 'style' );
	            if ( preg_match( '/background-image:\s*url\(["\']?([^"\']+)["\']?\)/i', $parent_style, $matches ) ) {
	                $img_url = $matches[1];
	            }
	        }

	        if ( ! empty( $img_url ) ) {
	            // Convert relative to absolute URL
	            if ( ! preg_match( '/^https?:\/\//i', $img_url ) ) {
	                $base_url = rtrim( $url, '/' );
	                if ( strpos( $img_url, '/' ) === 0 ) {
	                    $parsed = parse_url( $base_url );
	                    $img_url = $parsed['scheme'] . '://' . $parsed['host'] . $img_url;
	                } else {
	                    $img_url = $base_url . '/' . ltrim( $img_url, '/' );
	                }
	            }

	            // Clean up common lazy loading placeholder URLs
	            $placeholder_patterns = [
	                '/data:image\/[^;]+;base64,/',  // Base64 placeholders
	                '/placeholder\.(jpg|jpeg|png|gif|webp)$/i',  // Placeholder files
	                '/loading\.(jpg|jpeg|png|gif|webp)$/i',      // Loading images
	                '/^https?:\/\/via\.placeholder\.com\//',      // Placeholder services
	            ];
	            
	            $is_placeholder = false;
	            foreach ( $placeholder_patterns as $pattern ) {
	                if ( preg_match( $pattern, $img_url ) ) {
	                    $is_placeholder = true;
	                    break;
	                }
	            }
	            
	            // Skip nếu là placeholder image
	            if ( $is_placeholder ) {
	                $img_url = '';
	            }
	        }

	        if ( ! empty( $img_url ) ) {
	            // URL encode spaces and special chars in the path part only
	            $parsed_url = parse_url( $img_url );
	            if ( $parsed_url && isset( $parsed_url['path'] ) ) {
	                $parsed_url['path'] = str_replace( ' ', '%20', $parsed_url['path'] );
	                $img_url = $parsed_url['scheme'] . '://' . $parsed_url['host'] . $parsed_url['path'];
	                
	                // Add query string back if exists
	                if ( isset( $parsed_url['query'] ) ) {
	                    $img_url .= '?' . $parsed_url['query'];
	                }
	            }

	            // Kiểm tra URL có hợp lệ không (after encoding)
	            if ( validate_image_url( $img_url ) ) {
	                
	                require_once ABSPATH . 'wp-admin/includes/media.php';
	                require_once ABSPATH . 'wp-admin/includes/file.php';
	                require_once ABSPATH . 'wp-admin/includes/image.php';

	                // Enhanced headers để bypass lazy loading restrictions
	                add_filter( 'http_request_args', function( $args, $url_arg ) use ( $url ) {
	                    $args['headers']['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
	                    $args['headers']['Accept'] = 'image/webp,image/apng,image/*,*/*;q=0.8';
	                    $args['headers']['Accept-Language'] = 'en-US,en;q=0.9';
	                    $args['headers']['Cache-Control'] = 'no-cache';
	                    $args['headers']['Referer'] = $url; // Sử dụng URL gốc làm referer
	                    $args['timeout'] = 30; // Tăng timeout cho lazy loading
	                    return $args;
	                }, 10, 2);

	                $thumb_id = media_sideload_image( $img_url, $post_id, null, 'id' );
	                
	                // Remove filter sau khi dùng
	                remove_all_filters( 'http_request_args' );
	                
	                if ( ! is_wp_error( $thumb_id ) ) {
	                    set_post_thumbnail( $post_id, $thumb_id );
	                } else {
	                    // Thử phương án khác: download thủ công với retry mechanism
	                    $uploaded_file = init_manga_crawler_download_image_retry( $img_url, $post_id, $url );
	                }
	            }
	        }
	    }
	}

	wp_send_json_success([
		'post_id'  => $post_id,
		'title'    => $post_title,
		'chapters' => $chapters,
		'status'   => $final_status,
	]);
}

// Thêm chương
function init_manga_crawler_add_chapter() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( [ 'message' => 'Permission denied.' ] );
	}
	check_ajax_referer( 'im_crawler_run', 'nonce' );
	$manga_id         = intval( $_POST['post_id'] ?? 0 );
	$number           = floatval( $_POST['number'] ?? 0 );
	$url              = esc_url_raw( $_POST['url'] ?? '' );
	$content_selector = sanitize_text_field( $_POST['content_selector'] ?? '' );
	if ( ! $manga_id || ! $number || empty( $url ) || empty( $content_selector ) ) {
		wp_send_json_error( [ 'message' => 'Missing chapter data.' ] );
	}
	global $wpdb;
	$table = $wpdb->prefix . 'init_manga_chapters';
	$slug  = init_manga_generate_chapter_slug( $number );
	// Check if chapter already exists
	$exists = $wpdb->get_var( $wpdb->prepare(
		"SELECT id FROM $table WHERE manga_id = %d AND chapter_slug = %s",
		$manga_id, $slug
	) );
	if ( $exists ) {
		wp_send_json_success([
			'message' => 'Chapter already exists, skipped.',
			'status'  => 'already_exists',
			'number'  => $number,
		]);
	}
	// Crawl content
	$html = init_manga_crawler_fetch_html( $url );
	if ( is_wp_error( $html ) ) {
		wp_send_json_error( [ 'message' => $html->get_error_message() ] );
	}
	libxml_use_internal_errors( true );
	$doc = new DOMDocument();
	
	// Thêm encoding handling
	$html = mb_convert_encoding( $html, 'HTML-ENTITIES', 'UTF-8' );
	@$doc->loadHTML( $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	
	$xpath = new DOMXPath( $doc );
	$content = '';
	$xpath_query = convert_css_to_xpath( $content_selector );
	$elements = @$xpath->query( $xpath_query );
	
	if ( $elements && $elements->length > 0 ) {
		foreach ( $elements as $el ) {
			$content .= $doc->saveHTML( $el );
		}
		$content = filter_safe_content( $content );
		
		// Áp dụng CSS content extraction sau filter_safe_content
		$content = init_manga_crawler_extract_css_content( $content, $doc );

		$content = fully_decode_html( $content );
	}
	if ( empty( $content ) ) {
		wp_send_json_error( [ 'message' => 'Chapter content not found.' ] );
	}
	$result = init_manga_save_chapter([
		'manga_id' => $manga_id,
		'number'   => $number,
		'content'  => $content,
	]);
	if ( is_wp_error( $result ) ) {
		wp_send_json_error([
			'message' => $result->get_error_message(),
			'code'    => $result->get_error_code(),
		]);
	}
	wp_send_json_success([
		'message' => 'Chapter saved successfully.',
		'status'  => 'inserted',
		'number'  => $number,
	]);
}
