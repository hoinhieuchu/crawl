<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Auto crawl và thêm chapter mới cho manga
 * 
 * @param int $manga_id ID của manga post
 * @param bool $return_info Có return thông tin chi tiết không
 * @return array|bool Thông tin crawl hoặc true/false
 */
function init_manga_auto_crawl_new_chapters( $manga_id, $return_info = false ) {
    global $wpdb;
    
    // Validate manga ID
    if ( ! $manga_id || ! get_post( $manga_id ) ) {
        return false;
    }
    
    // Lấy thông tin cần thiết từ meta
    $crawl_url = get_post_meta( $manga_id, '_imc_crawl_url', true );
    $chapters_selector = get_post_meta( $manga_id, '_imc_selector_chapters', true );
    $content_selector = get_post_meta( $manga_id, '_imc_selector_content', true );
    
    if ( empty( $crawl_url ) || empty( $chapters_selector ) || empty( $content_selector ) ) {
        if ( $return_info ) {
            return [
                'success' => false,
                'message' => 'Missing crawl configuration for this manga.',
                'new_chapters' => 0
            ];
        }
        return false;
    }
    
    // Fetch HTML từ trang gốc
    $html = init_manga_crawler_fetch_html( $crawl_url );
    if ( is_wp_error( $html ) ) {
        if ( $return_info ) {
            return [
                'success' => false,
                'message' => 'Failed to fetch HTML: ' . $html->get_error_message(),
                'new_chapters' => 0
            ];
        }
        return false;
    }
    
    // Parse HTML
    libxml_use_internal_errors( true );
    $doc = new DOMDocument();
    $html = mb_convert_encoding( $html, 'HTML-ENTITIES', 'UTF-8' );
    @$doc->loadHTML( $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
    $xpath = new DOMXPath( $doc );
    
    // Lấy danh sách chapter từ trang
    $get_links = function( $selector ) use ( $xpath, $crawl_url ) {
        if ( empty( $selector ) ) return [];
        
        $xpath_query = convert_css_to_xpath( $selector );
        $elements = @$xpath->query( $xpath_query );
        $list = [];
        
        if ( $elements && $elements->length > 0 ) {
            foreach ( $elements as $el ) {
                $href = $el->getAttribute('href');
                $text = trim( $el->textContent );
                
                if ( ! empty( $href ) && ! empty( $text ) ) {
                    // Convert relative URLs to absolute
                    if ( ! filter_var( $href, FILTER_VALIDATE_URL ) ) {
                        $base_url = rtrim( $crawl_url, '/' );
                        if ( strpos( $href, '/' ) === 0 ) {
                            $parsed = parse_url( $base_url );
                            $href = $parsed['scheme'] . '://' . $parsed['host'] . $href;
                        } else {
                            $href = $base_url . '/' . ltrim( $href, '/' );
                        }
                    }
                    
                    // Extract chapter number từ title
                    $chapter_number = init_manga_extract_chapter_number( $text );
                    
                    if ( $chapter_number > 0 ) {
                        $list[] = [
                            'name' => $text,
                            'url'  => esc_url_raw( $href ),
                            'number' => $chapter_number
                        ];
                    }
                }
            }
        }
        
        return $list;
    };
    
    $chapters = $get_links( $chapters_selector );
    
    if ( empty( $chapters ) ) {
        if ( $return_info ) {
            return [
                'success' => false,
                'message' => 'No chapters found on the source page.',
                'new_chapters' => 0
            ];
        }
        return false;
    }
    
    // Lấy chapter cao nhất hiện có trong database
    $table = $wpdb->prefix . 'init_manga_chapters';
    $max_chapter = $wpdb->get_var( $wpdb->prepare(
        "SELECT MAX(chapter_number) FROM $table WHERE manga_id = %d",
        $manga_id
    ) );
    
    $max_chapter = $max_chapter ? floatval( $max_chapter ) : 0;
    
    // Lọc ra những chapter mới (số lớn hơn max hiện tại)
    $new_chapters = array_filter( $chapters, function( $chapter ) use ( $max_chapter ) {
        return $chapter['number'] > $max_chapter;
    } );
    
    if ( empty( $new_chapters ) ) {
        if ( $return_info ) {
            return [
                'success' => true,
                'message' => 'No new chapters found.',
                'new_chapters' => 0,
                'max_chapter' => $max_chapter
            ];
        }
        return true;
    }
    
    // Sort theo thứ tự tăng dần để thêm từ chapter cũ lên mới
    usort( $new_chapters, function( $a, $b ) {
        return $a['number'] <=> $b['number'];
    } );
    
    $added_chapters = [];
    $failed_chapters = [];
    
    // Thêm từng chapter mới
    foreach ( $new_chapters as $chapter ) {
        $chapter_html = init_manga_crawler_fetch_html( $chapter['url'] );
        
        if ( is_wp_error( $chapter_html ) ) {
            $failed_chapters[] = [
                'number' => $chapter['number'],
                'error' => $chapter_html->get_error_message()
            ];
            continue;
        }
        
        // Parse chapter content
        libxml_use_internal_errors( true );
        $chapter_doc = new DOMDocument();
        $chapter_html = mb_convert_encoding( $chapter_html, 'HTML-ENTITIES', 'UTF-8' );
        @$chapter_doc->loadHTML( $chapter_html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
        $chapter_xpath = new DOMXPath( $chapter_doc );
        
        $content = '';
        $content_xpath_query = convert_css_to_xpath( $content_selector );
        $content_elements = @$chapter_xpath->query( $content_xpath_query );
        
        if ( $content_elements && $content_elements->length > 0 ) {
            foreach ( $content_elements as $el ) {
                $content .= $chapter_doc->saveHTML( $el );
            }

            $content = filter_safe_content( $content );
        
            // Áp dụng CSS content extraction sau filter_safe_content
            $content = init_manga_crawler_extract_css_content( $content, $doc );
        }
        
        if ( empty( $content ) ) {
            $failed_chapters[] = [
                'number' => $chapter['number'],
                'error' => 'Chapter content not found'
            ];
            continue;
        }
        
        // Save chapter
        $result = init_manga_save_chapter([
            'manga_id' => $manga_id,
            'number'   => $chapter['number'],
            'content'  => $content,
        ]);
        
        if ( is_wp_error( $result ) ) {
            $failed_chapters[] = [
                'number' => $chapter['number'],
                'error' => $result->get_error_message()
            ];
        } else {
            $added_chapters[] = [
                'number' => $chapter['number'],
                'name' => $chapter['name']
            ];
        }
        
        // Thêm delay nhỏ để tránh spam request
        usleep( 500000 ); // 0.5 giây
    }
    
    if ( $return_info ) {
        return [
            'success' => true,
            'message' => sprintf( 'Added %d new chapters', count( $added_chapters ) ),
            'new_chapters' => count( $added_chapters ),
            'added_chapters' => $added_chapters,
            'failed_chapters' => $failed_chapters,
            'max_chapter_before' => $max_chapter,
            'max_chapter_after' => !empty($added_chapters) ? max(array_column($added_chapters, 'number')) : $max_chapter
        ];
    }
    
    return count( $added_chapters ) > 0;
}

/**
 * Hàm helper để extract số chapter từ title
 * 
 * @param string $title Title của chapter
 * @return float Số chapter
 */
function init_manga_extract_chapter_number( $title ) {
    // Các pattern phổ biến để extract chapter number
    $patterns = [
        '/(?:chapter|chap|ch\.?)\s*(\d+(?:\.\d+)?)/i',
        '/(?:chương|chuong)\s*(\d+(?:\.\d+)?)/i',
        '/(\d+(?:\.\d+)?)$/i', // Số ở cuối string
        '/(\d+(?:\.\d+)?)/i', // Bất kỳ số nào
    ];
    
    foreach ( $patterns as $pattern ) {
        if ( preg_match( $pattern, $title, $matches ) ) {
            return floatval( $matches[1] );
        }
    }
    
    return 0;
}

/**
 * Wrapper function để gọi dễ dàng trong single-manga.php
 * 
 * @param int $manga_id ID của manga
 * @return array Thông tin chi tiết về việc crawl
 */
function check_and_add_new_chapters( $manga_id ) {
    return init_manga_auto_crawl_new_chapters( $manga_id, true );
}

/**
 * Hàm để check nhanh có chapter mới không (chỉ return true/false)
 * 
 * @param int $manga_id ID của manga
 * @return bool Có chapter mới được thêm hay không
 */
function has_new_chapters( $manga_id ) {
    return init_manga_auto_crawl_new_chapters( $manga_id, false );
}
