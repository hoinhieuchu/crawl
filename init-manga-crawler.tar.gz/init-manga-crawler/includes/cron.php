<?php
/**
 * Cron job auto crawl manga ongoing - OPTIMIZED VERSION
 */
// Register cron schedule
add_filter('cron_schedules', 'init_manga_add_cron_interval');
function init_manga_add_cron_interval($schedules) {
    $schedules['hourly_manga_crawl'] = array(
        'interval' => 3600, // 1 hour
        'display'  => __('Every Hour for Manga Crawl')
    );
    return $schedules;
}

// Schedule cron on activation
register_activation_hook(__FILE__, 'init_manga_schedule_cron');
function init_manga_schedule_cron() {
    if (!wp_next_scheduled('init_manga_hourly_crawl')) {
        wp_schedule_event(time(), 'hourly_manga_crawl', 'init_manga_hourly_crawl');
    }
}

// Unschedule on deactivation
register_deactivation_hook(__FILE__, 'init_manga_unschedule_cron');
function init_manga_unschedule_cron() {
    wp_clear_scheduled_hook('init_manga_hourly_crawl');
}

// Main cron function - OPTIMIZED
add_action('init_manga_hourly_crawl', 'init_manga_execute_hourly_crawl');
function init_manga_execute_hourly_crawl() {
    // Set time limit cao hơn cho cron
    @set_time_limit(600); // 10 phút
    
    // Query manga cần crawl - ĐÃ TỐI ƯU: Filter _imc_crawl_url ngay trong query
    $manga_posts = get_posts(array(
        'post_type'      => 'manga',
        'post_status'    => 'publish',
        'posts_per_page' => 300,
        'orderby'        => 'date',
        'order'          => 'DESC', // Mới nhất trước
        'meta_query'     => array(
            'relation' => 'AND',
            // Check status = ongoing
            array(
                'relation' => 'OR',
                array(
                    'key'     => 'status',
                    'value'   => 'ongoing',
                    'compare' => '='
                ),
                array(
                    'key'     => 'status',
                    'compare' => 'NOT EXISTS'
                )
            ),
            // Check last crawl time
            array(
                'relation' => 'OR',
                array(
                    'key'     => '_last_auto_crawl',
                    'value'   => time() - 10800, // 3 hours ago
                    'compare' => '<',
                    'type'    => 'NUMERIC'
                ),
                array(
                    'key'     => '_last_auto_crawl',
                    'compare' => 'NOT EXISTS'
                )
            ),
            array(
                'key'     => '_imc_crawl_url',
                'value'   => '',
                'compare' => '!='
            )
        )
    ));
    
    if (empty($manga_posts)) {
        return;
    }
    
    $crawled_count = 0;
    $success_count = 0;
    
    foreach ($manga_posts as $post) {
        // ✅ Bỏ các check không cần thiết vì đã filter trong query rồi
        // Chỉ cần lấy crawl_url để dùng
        $crawl_url = get_post_meta($post->ID, '_imc_crawl_url', true);
        
        // Execute crawl
        $result = init_manga_auto_crawl_new_chapters($post->ID, false);
        
        $crawled_count++;
        if ($result) {
            $success_count++;
        }
        
        // Delay nhỏ giữa các manga để tránh overload
        usleep(100000); // 0.1 second
        
        // Break nếu đã chạy quá lâu (8 phút)
        if ((time() - $_SERVER['REQUEST_TIME']) > 480) {
            break;
        }
    }
    
    // Optional: Log kết quả (nếu cần debug)
    // update_option('_manga_cron_last_run', array(
    //     'time' => time(),
    //     'crawled' => $crawled_count,
    //     'success' => $success_count,
    //     'total_found' => count($manga_posts)
    // ));
}

// Fallback: Ensure cron is scheduled (chạy mỗi khi init)
add_action('init', 'init_manga_ensure_cron_scheduled');
function init_manga_ensure_cron_scheduled() {
    if (!wp_next_scheduled('init_manga_hourly_crawl')) {
        wp_schedule_event(time(), 'hourly_manga_crawl', 'init_manga_hourly_crawl');
    }
}
