<?php
/**
 * Simple hook để auto crawl chapter mới khi vào trang single manga
 */
add_action('wp', 'init_manga_silent_auto_crawl');

function init_manga_silent_auto_crawl() {
    // Chỉ chạy trên single manga page
    if (!is_singular('manga')) {
        return;
    }
    
    $manga_id = get_the_ID();
    if (!$manga_id) {
        return;
    }
    
    // Throttle để tránh crawl liên tục - 1 giờ 1 lần
    $last_crawl = get_post_meta($manga_id, '_last_auto_crawl', true);
    if ($last_crawl && (time() - $last_crawl) < 3600) {
        return;
    }
    
    // Update timestamp ngay để tránh duplicate
    update_post_meta($manga_id, '_last_auto_crawl', time());
    
    // Gọi hàm crawl - silent mode
    init_manga_auto_crawl_new_chapters($manga_id, false);
}
