<?php
if ( ! defined( 'ABSPATH' ) ) exit;

// Add menu under Init Manga
add_action( 'admin_menu', function() {
	add_submenu_page(
		'init-manga-settings',
		__( 'Init Manga Crawler', 'init-manga-crawler' ),
		__( 'Crawler', 'init-manga-crawler' ),
		'manage_options',
		'init-manga-crawler',
		'init_manga_crawler_admin_page'
	);
}, 999 );

function init_manga_crawler_admin_page() {
	if ( ! init_manga_crawler_is_allowed() ) {
		echo '<div class="notice notice-error"><p>';
		esc_html_e( 'Init Manga Crawler requires the Init Manga theme to be active. Please switch to the Init Manga theme to use this plugin.', 'init-manga-crawler' );
		echo '</p></div>';
		return;
	}
	
	// Get saved presets
	$saved_presets = get_option( 'init_manga_crawler_presets', [] );
	
	$status = 'ongoing'; // default
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Init Manga Crawler', 'init-manga-crawler' ); ?></h1>
		
		<!-- Preset Management Section -->
		<div class="postbox" style="margin-block: 20px; padding: 15px 20px;">
			<h2 style="margin-top: 0;"><?php esc_html_e( 'Preset Management', 'init-manga-crawler' ); ?></h2>
			
			<div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
				<select id="preset-selector" style="min-width: 200px;">
					<option value=""><?php esc_html_e( 'Select a preset...', 'init-manga-crawler' ); ?></option>
					<?php foreach ( $saved_presets as $preset_name => $preset_data ): ?>
						<option value="<?php echo esc_attr( $preset_name ); ?>">
							<?php echo esc_html( $preset_name ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				
				<button type="button" class="button" id="load-preset">
					<?php esc_html_e( 'Load Preset', 'init-manga-crawler' ); ?>
				</button>
				
				<input type="text" id="preset-name" placeholder="<?php esc_attr_e( 'Preset name...', 'init-manga-crawler' ); ?>" style="min-width: 150px;">
				
				<button type="button" class="button button-secondary" id="save-preset">
					<?php esc_html_e( 'Save Current Settings', 'init-manga-crawler' ); ?>
				</button>
				
				<button type="button" class="button" id="delete-preset" style="color: #d63638;">
					<?php esc_html_e( 'Delete Preset', 'init-manga-crawler' ); ?>
				</button>
			</div>
			
			<div style="margin-top: 10px;">
				<button type="button" class="button" id="export-presets"><?php esc_html_e( 'Export Presets', 'init-manga-crawler' ); ?></button>
				<input type="file" id="import-presets" style="display: none;" accept=".json">
				<button type="button" class="button" id="import-presets-btn"><?php esc_html_e( 'Import Presets', 'init-manga-crawler' ); ?></button>
			</div>
			
			<p class="description" style="margin-top: 10px;">
				<?php esc_html_e( 'Save your current crawler configuration as a preset to reuse later. Perfect for switching between different manga sites!', 'init-manga-crawler' ); ?>
			</p>
		</div>

		<form id="init-manga-crawler-form" action="javascript:void(0);">
			<table class="form-table" role="presentation">
				<tbody>
					<tr>
					    <th scope="row"><?php esc_html_e( 'Pre-processing Form', 'init-manga-crawler' ); ?></th>
					    <td>
					        <input type="text" id="preprocess_url" class="regular-text" placeholder="<?php esc_attr_e( 'List page URL to crawl...', 'init-manga-crawler' ); ?>">
					        <input type="text" id="preprocess_selector" class="regular-text" placeholder="<?php esc_attr_e( 'Selector for manga links (e.g. .list-manga a)', 'init-manga-crawler' ); ?>">
					        <button type="button" class="button" id="preprocess-fetch">
					            <?php esc_html_e( 'Fetch Links', 'init-manga-crawler' ); ?>
					        </button>
					        <p class="description"><?php esc_html_e( 'Enter a list page URL and a CSS selector to extract manga links. The results will be inserted below.', 'init-manga-crawler' ); ?></p>
					    </td>
					</tr>

					<tr>
					    <th scope="row"><label for="crawl_link"><?php esc_html_e( 'Manga URL(s)', 'init-manga-crawler' ); ?></label></th>
					    <td>
					        <textarea name="crawl_link" id="crawl_link" class="large-text" rows="8" placeholder="<?php esc_attr_e( 'Nhập mỗi URL truyện trên một dòng...', 'init-manga-crawler' ); ?>"></textarea>
					        <p class="description"><?php esc_html_e( 'You can enter multiple URLs, one per line, to crawl them in sequence.', 'init-manga-crawler' ); ?></p>
					    </td>
					</tr>
					<tr>
						<th scope="row"><label for="selector_title"><?php esc_html_e( 'Title Selector', 'init-manga-crawler' ); ?></label></th>
						<td><input name="selector_title" type="text" id="selector_title" class="regular-text" placeholder="h1 .title"></td>
					</tr>
					<tr>
						<th scope="row"><label for="selector_description"><?php esc_html_e( 'Description Selector', 'init-manga-crawler' ); ?></label></th>
						<td><input name="selector_description" type="text" id="selector_description" class="regular-text" placeholder=".description, .summary, etc."></td>
					</tr>
					<tr>
						<th scope="row"><label for="selector_author"><?php esc_html_e( 'Author Selector', 'init-manga-crawler' ); ?></label></th>
						<td><input name="selector_author" type="text" id="selector_author" class="regular-text" placeholder=".author"></td>
					</tr>
					<tr>
						<th scope="row"><label for="selector_genres"><?php esc_html_e( 'Genres Selector', 'init-manga-crawler' ); ?></label></th>
						<td><input name="selector_genres" type="text" id="selector_genres" class="regular-text" placeholder=".genres a"></td>
					</tr>
					<tr>
					    <th scope="row"><label for="selector_status"><?php esc_html_e( 'Status Selector', 'init-manga-crawler' ); ?></label></th>
					    <td>
					        <input name="selector_status" type="text" id="selector_status" class="regular-text" placeholder=".status">
					    </td>
					</tr>
					<tr>
						<th scope="row"><label for="selector_cover"><?php esc_html_e( 'Cover Image Selector', 'init-manga-crawler' ); ?></label></th>
						<td><input name="selector_cover" type="text" id="selector_cover" class="regular-text" placeholder="img.cover, .manga-thumb img"></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Type', 'init-manga' ); ?></th>
						<td>
							<div class="manga-metabox-group">
								<fieldset>
									<label><input type="radio" name="type" value="novel" checked> <?php esc_html_e('Novel', 'init-manga'); ?></label><br>
									<label><input type="radio" name="type" value="comic"> <?php esc_html_e('Comic', 'init-manga'); ?></label><br>
								</fieldset>
							</div>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="selector_chapters"><?php esc_html_e( 'Chapter List Selector', 'init-manga-crawler' ); ?></label></th>
						<td><input name="selector_chapters" type="text" id="selector_chapters" class="regular-text" placeholder=".chapters a"></td>
					</tr>
					<tr>
						<th scope="row"><label for="selector_content"><?php esc_html_e( 'Chapter Content Selector', 'init-manga-crawler' ); ?></label></th>
						<td><input name="selector_content" type="text" id="selector_content" class="regular-text" placeholder=".reading-content"></td>
					</tr>
				</tbody>
			</table>

			<?php wp_nonce_field( 'im_crawler_run', '_im_crawler_nonce' ); ?>

			<p class="submit">
				<button id="im-crawl-button" class="button button-primary">
					<?php esc_html_e( 'Start Crawling', 'init-manga-crawler' ); ?>
				</button>
			</p>

			<div id="im-crawl-log" style="margin-top:1em;max-height:750px;overflow:auto;background:#fff;padding:10px;border:1px solid #ddd;display:none;">
				<strong><?php esc_html_e( 'Log:', 'init-manga-crawler' ); ?></strong>
				<ul id="im-crawl-log-list" style="list-style:decimal;margin-left:20px;"></ul>
			</div>
		</form>

		<hr style="margin-top:40px;margin-bottom:20px;">

		<div class="postbox" style="padding:20px 30px;">
			<h2><?php esc_html_e( 'Usage Guide', 'init-manga-crawler' ); ?></h2>
			
			<p><?php esc_html_e( 'To crawl a specific manga, simply enter its URL and fill in the appropriate CSS selectors. The system will fetch the HTML content and create a manga post automatically.', 'init-manga-crawler' ); ?></p>

			<h3 style="margin-top:20px;"><?php esc_html_e( 'Auto Extract Manga URLs from a List Page', 'init-manga-crawler' ); ?></h3>
			<p><?php esc_html_e( 'You can also extract multiple manga URLs from a list page using a CSS selector. Just enter the page URL and the link selector, then click "Fetch Links". The extracted URLs will be inserted into the Manga URL(s) field below.', 'init-manga-crawler' ); ?></p>
			<p><?php esc_html_e( 'Example:', 'init-manga-crawler' ); ?></p>
			<ul style="list-style:disc;padding-left:20px;">
				<li><strong><?php esc_html_e( 'List Page URL', 'init-manga-crawler' ); ?>:</strong> <code>https://vivutruyen2.net/moi-cap-nhat/</code></li>
				<li><strong><?php esc_html_e( 'Link Selector', 'init-manga-crawler' ); ?>:</strong> <code>.page-content .uk-cover-container a.uk-position-cover</code></li>
			</ul>

			<h3 style="margin-top:20px;"><?php esc_html_e( 'Example: vivutruyen2.net', 'init-manga-crawler' ); ?></h3>
			<p><?php esc_html_e( 'This example shows how to crawl a single manga using the detail page URL.', 'init-manga-crawler' ); ?></p>
			<ul style="list-style:disc;padding-left:20px;">
				<li><strong><?php esc_html_e( 'Manga URL', 'init-manga-crawler' ); ?>:</strong> <code>https://vivutruyen2.net/o-re-man-kich-va-su-tra-gia/</code></li>
				<li><strong><?php esc_html_e( 'Title Selector', 'init-manga-crawler' ); ?>:</strong> <code>h1 a.title-truyen</code></li>
				<li><strong><?php esc_html_e( 'Description Selector', 'init-manga-crawler' ); ?>:</strong> <code>div.noi-dung</code></li>
				<li><strong><?php esc_html_e( 'Author Selector', 'init-manga-crawler' ); ?>:</strong> <code>ul.info-truyen li:first-child a</code></li>
				<li><strong><?php esc_html_e( 'Genres Selector', 'init-manga-crawler' ); ?>:</strong> <code>ul.info-truyen li:nth-child(2) a</code></li>
				<li><strong><?php esc_html_e( 'Cover Image Selector', 'init-manga-crawler' ); ?>:</strong> <code>div.image-truyen img.slider-image</code></li>
				<li><strong><?php esc_html_e( 'Type', 'init-manga' ); ?>:</strong> <?php esc_html_e( 'Novel', 'init-manga' ); ?></li>
				<li><strong><?php esc_html_e( 'Status', 'init-manga' ); ?>:</strong> <code>ul.info-truyen li:nth-child(3)</code></li>
				<li><strong><?php esc_html_e( 'Chapter List Selector', 'init-manga-crawler' ); ?>:</strong> <code>a.chap-title</code></li>
				<li><strong><?php esc_html_e( 'Chapter Content Selector', 'init-manga-crawler' ); ?>:</strong> <code>div.reading</code></li>
			</ul>
		</div>
	</div>

	<!-- Hidden input to store presets data for JS -->
	<script type="text/javascript">
		var savedPresets = <?php echo json_encode( $saved_presets ); ?>;
	</script>
	<?php
}

// Enqueue admin JS & localize AJAX data
add_action( 'admin_enqueue_scripts', function( $hook ) {
	if ( $hook !== 'init-manga_page_init-manga-crawler' ) {
		return;
	}

	wp_enqueue_script(
		'init-manga-crawler-admin',
		INIT_MANGA_CRAWLER_URL . 'assets/js/crawler-admin.js',
		[ 'jquery' ],
		INIT_MANGA_CRAWLER_VERSION,
		true
	);

	wp_enqueue_script(
		'init-manga-crawler-presets',
		INIT_MANGA_CRAWLER_URL . 'assets/js/crawler-presets.js',
		[ 'jquery', 'init-manga-crawler-admin' ],
		INIT_MANGA_CRAWLER_VERSION,
		true
	);

	$i18n_strings = [
		'missing_input'         => __( 'Please enter both URL and selector.', 'init-manga-crawler' ),
		'fetch_links'		    => __( 'Fetch Links', 'init-manga-crawler' ),
		'fetching_links'        => __( 'Fetching...', 'init-manga-crawler' ),
		'fetch_links_done'      => __( 'Fetched %d link(s) from list page.', 'init-manga-crawler' ),
		'fetch_failed'          => __( 'AJAX request failed while fetching list page.', 'init-manga-crawler' ),
		'fetch_error_prefix'    => __( 'Error: ', 'init-manga-crawler' ),
		'crawling_text'         => __( 'Crawling...', 'init-manga-crawler' ),
		'start_text'            => __( 'Start Crawling', 'init-manga-crawler' ),
		'no_url_error'          => '❌ ' . __( 'Please enter at least one manga URL.', 'init-manga-crawler' ),
		'batch_start'           => '🚀 ' . __( 'Starting batch crawl for %d manga(s)...', 'init-manga-crawler' ),
		'batch_complete'        => '🎉 ' . __( 'COMPLETE! The entire queue has been processed.', 'init-manga-crawler' ),
		'total_time'            => '⏱️ ' . __( 'Total time: %s seconds', 'init-manga-crawler' ),
		'processing_start'      => '<hr style="margin-block: 10px"><strong>' . __( 'Processing: %s', 'init-manga-crawler' ) . '</strong>',
		'manga_info_ok'         => '✅ ' . __( 'Manga info OK (ID: %d) – Title: "%s"', 'init-manga-crawler' ),
		'chapters_found'        => '📚 ' . __( 'Found %d chapter(s).', 'init-manga-crawler' ),
		'manga_info_error'      => '❌ ' . __( 'Error fetching manga info: %s', 'init-manga-crawler' ),
		'ajax_manga_error'      => '❌ ' . __( 'Critical AJAX error while processing manga.', 'init-manga-crawler' ),
		'chapters_complete'     => '✅ ' . __( 'Finished processing chapters for manga ID: %d.', 'init-manga-crawler' ),
		'crawling_chapter'      => '📥 ' . __( 'Crawling chapter: %s', 'init-manga-crawler' ),
		'chapter_skipped'       => '- ' . __( 'Skipped (already exists): Chapter %s', 'init-manga-crawler' ),
		'chapter_saved'         => '- ' . __( 'Saved successfully: Chapter %s', 'init-manga-crawler' ),
		'chapter_error'         => '- ' . __( 'Error on Chapter %s – %s', 'init-manga-crawler' ),
		'ajax_chapter_error'    => '- ' . __( 'Critical AJAX error while crawling chapter %s.', 'init-manga-crawler' ),
		'unknown_error'         => __( 'Unknown error', 'init-manga-crawler' ),
		
		// Preset-related strings
		'preset_name_required'  => __( 'Please enter a preset name.', 'init-manga-crawler' ),
		'preset_select_required'=> __( 'Please select a preset to load.', 'init-manga-crawler' ),
		'preset_delete_confirm' => __( 'Are you sure you want to delete this preset?', 'init-manga-crawler' ),
		'preset_saved'          => __( 'Preset saved successfully!', 'init-manga-crawler' ),
		'preset_loaded'         => __( 'Preset loaded successfully!', 'init-manga-crawler' ),
		'preset_deleted'        => __( 'Preset deleted successfully!', 'init-manga-crawler' ),
		'preset_save_error'     => __( 'Error saving preset.', 'init-manga-crawler' ),
		'preset_delete_error'   => __( 'Error deleting preset.', 'init-manga-crawler' ),
		'presets_imported'      => __( 'Presets imported successfully!', 'init-manga-crawler' ),
		'import_error'          => __( 'Error importing presets.', 'init-manga-crawler' ),
		'invalid_json'          => __( 'Invalid JSON file.', 'init-manga-crawler' ),
	];

	wp_localize_script(
		'init-manga-crawler-admin',
		'InitMangaCrawler',
		[
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'im_crawler_run' ),
			'i18n'     => $i18n_strings,
		]
	);
} );
