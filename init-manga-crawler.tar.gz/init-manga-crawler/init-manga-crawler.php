<?php
/**
 * Plugin Name: Init Manga Crawler
 * Plugin URI:  https://inithtml.com/plugin/init-manga-crawler/
 * Description: A lightweight and customizable manga crawler for WordPress. Designed to work seamlessly with the Init Manga theme.
 * Version:     1.6
 * Author:      Init HTML
 * Author URI:  https://inithtml.com/
 * Requires at least: 5.5
 * Tested up to: 6.8
 * Requires PHP: 7.4
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: init-manga-crawler
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// Define constants
define( 'INIT_MANGA_CRAWLER_VERSION', '1.6' );
define( 'INIT_MANGA_CRAWLER_DIR', plugin_dir_path( __FILE__ ) );
define( 'INIT_MANGA_CRAWLER_URL', plugin_dir_url( __FILE__ ) );

// Load core logic
require_once INIT_MANGA_CRAWLER_DIR . 'includes/crawler-core.php';
require_once INIT_MANGA_CRAWLER_DIR . 'includes/crawler-auto.php';
require_once INIT_MANGA_CRAWLER_DIR . 'includes/crawler-preset.php';
require_once INIT_MANGA_CRAWLER_DIR . 'includes/crawler-utils.php';
require_once INIT_MANGA_CRAWLER_DIR . 'includes/hooks.php';
require_once INIT_MANGA_CRAWLER_DIR . 'includes/cron.php';

// Load admin interface
if ( is_admin() ) {
	require_once INIT_MANGA_CRAWLER_DIR . 'includes/crawler-admin.php';
}

// Load text domain
add_action( 'plugins_loaded', function() {
	load_plugin_textdomain( 'init-manga-crawler', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
} );
