=== Init Manga Crawler ===
Contributors: brokensmile.2103  
Tags: manga, crawler, scraper, content, import  
Requires at least: 5.5  
Tested up to: 6.8  
Requires PHP: 7.4  
Stable tag: 1.6
License: GPLv2 or later  
License URI: https://www.gnu.org/licenses/gpl-2.0.html  

A lightweight and customizable manga crawler for WordPress. Designed to work seamlessly with the Init Manga theme.

== Description ==

**Init Manga Crawler** lets you fetch manga content from external websites and convert it into posts compatible with the [Init Manga](https://inithtml.com/theme/init-manga/) theme.

Built for developers and admins who want to quickly import manga from third-party sites without coding custom scripts. You can define your own CSS selectors for each field (title, cover, author, etc.) and extract full chapter lists and content using a simple form.

**Features:**
- Crawler UI integrated directly in WP Admin
- Customizable selectors for title, description, author, genres, cover, chapters...
- Bulk crawling support (enter multiple URLs, one per line)
- Pre-processing mode: auto-extract manga links from list pages
- Creates WordPress posts using Init Manga post type
- Logs every step of the crawl process in real time
- Clean and minimal design for efficient workflow

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/init-manga-crawler` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to **Init Manga → Crawler** in the admin sidebar.
4. Enter the target URL(s) and configure the CSS selectors.
5. Click **Start Crawling** to import the manga.

== Frequently Asked Questions ==

= Does it work with any site? =  
No. It depends on the structure of the target website. You must define proper CSS selectors to match each field.

= Can I crawl multiple manga at once? =  
Yes. Starting from v1.1, you can enter multiple manga URLs (one per line) and the system will process them sequentially.

= Can it auto-detect manga links from a list page? =  
Yes. You can use the "Pre-processing" input to extract all manga links from a listing page using a CSS selector.

= Is JavaScript-rendered content supported? =  
No. This crawler only works with static HTML responses. It can't parse content rendered by JavaScript.

== Screenshots ==

1. The crawler UI
2. Example selector settings
3. Crawl log output

== Changelog ==

= 1.6 – July 31, 2025 =
- Preset Management System – Save and reuse crawler configurations for different manga sites
- Added preset save/load/delete functionality with dropdown selector
- Export/Import presets as JSON files for easy backup and sharing
- Auto-save form state to localStorage with session recovery on page reload
- Keyboard shortcuts: Use Ctrl+1-9 to quick-load presets by order
- Enhanced UI with preset management section and improved notifications
- Modular code structure: Separated preset logic into dedicated files for better maintenance

= 1.5 – July 23, 2025 =
- Improved chapter fetching: Added support for lazy-loaded images to ensure accurate content extraction
- Smarter content replacement: Enhanced logic to clean and reformat chapter HTML more intelligently
- Reversed chapter order: Now fetches chapters from oldest to newest for proper sequencing
- Added support for "Ngoại Truyện" chapters: These are now detected and imported correctly
- Auto-detect completion status: Automatically sets manga as "Completed" if no more chapters are found or based on detected cues

= 1.4 – July 22, 2025 =
- Enhanced security: Added comprehensive content filtering to remove dangerous HTML tags (script, style, iframe) and malicious attributes
- Improved image handling: Fixed URL validation for cover images with special characters and encoded URLs
- Better encoding support: Enhanced HTML parsing with proper UTF-8 encoding conversion
- Optimized image download: Added custom headers and fallback mechanisms for blocked image sources
- Code cleanup: Replaced deprecated get_page_by_title with WP_Query for better performance
- Enhanced error logging: More detailed debugging information for troubleshooting crawling issues

= 1.3 – July 19, 2025 =
- Added automatic hourly cron job to crawl new chapters for all ongoing manga
- Added silent hook to auto-update chapters when visiting a manga's single page
- New logic ensures updated content without manual intervention, with throttling to avoid overload

= 1.2 – July 17, 2025 =
- Added a content filter hook to allow modifying chapter content before output (e.g. removing specific HTML fragments for certain content types)
- Enhanced link extraction: automatically mirrors URLs across equivalent domains when detected

= 1.1 – July 17, 2025 =
- Added support for batch crawling (multiple URLs)
- New pre-processing tool to extract manga links from list pages
- Improved form auto-save, error handling, and UX
- Better DOM parsing and selector compatibility

= 1.0 – July 16, 2025=
- Initial release – core crawling form, input validation, AJAX handler stub
