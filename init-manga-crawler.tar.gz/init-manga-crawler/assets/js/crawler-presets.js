/**
 * Preset Management JavaScript
 * File: assets/js/crawler-presets.js
 */

jQuery(document).ready(function($) {
    
    // Helper Functions
    function getAllFormData() {
        return {
            preprocess_url: $('#preprocess_url').val(),
            preprocess_selector: $('#preprocess_selector').val(),
            selector_title: $('#selector_title').val(),
            selector_description: $('#selector_description').val(),
            selector_author: $('#selector_author').val(),
            selector_genres: $('#selector_genres').val(),
            selector_status: $('#selector_status').val(),
            selector_cover: $('#selector_cover').val(),
            type: $('input[name="type"]:checked').val(),
            selector_chapters: $('#selector_chapters').val(),
            selector_content: $('#selector_content').val()
        };
    }

    function loadFormData(data) {
        $('#preprocess_url').val(data.preprocess_url || '');
        $('#preprocess_selector').val(data.preprocess_selector || '');
        $('#selector_title').val(data.selector_title || '');
        $('#selector_description').val(data.selector_description || '');
        $('#selector_author').val(data.selector_author || '');
        $('#selector_genres').val(data.selector_genres || '');
        $('#selector_status').val(data.selector_status || '');
        $('#selector_cover').val(data.selector_cover || '');
        $('#selector_chapters').val(data.selector_chapters || '');
        $('#selector_content').val(data.selector_content || '');
        
        if (data.type) {
            $('input[name="type"][value="' + data.type + '"]').prop('checked', true);
        }
    }

    function updatePresetDropdown(presets) {
        const $selector = $('#preset-selector');
        $selector.empty().append('<option value="">' + InitMangaCrawler.i18n.preset_select_required + '</option>');
        
        $.each(presets, function(name, data) {
            $selector.append('<option value="' + name + '">' + name + '</option>');
        });
    }

    function showNotification(message, type = 'success') {
        const bgColor = type === 'success' ? '#4CAF50' : '#f44336';
        const $notification = $('<div style="position: fixed; top: 20px; right: 20px; background: ' + bgColor + '; color: white; padding: 10px 20px; border-radius: 4px; z-index: 9999;">' + message + '</div>');
        $('body').append($notification);
        setTimeout(function() {
            $notification.fadeOut(300, function() {
                $(this).remove();
            });
        }, 2000);
    }

    // Save Preset
    $('#save-preset').on('click', function() {
        const presetName = $('#preset-name').val().trim();
        
        if (!presetName) {
            alert(InitMangaCrawler.i18n.preset_name_required);
            return;
        }

        const formData = getAllFormData();
        const $button = $(this);
        const originalText = $button.text();
        
        $button.text('Saving...').prop('disabled', true);
        
        $.ajax({
            url: InitMangaCrawler.ajax_url,
            type: 'POST',
            data: {
                action: 'init_manga_save_preset',
                nonce: InitMangaCrawler.nonce,
                preset_name: presetName,
                preset_data: JSON.stringify(formData)
            },
            success: function(response) {
                if (response.success) {
                    showNotification(response.data.message);
                    savedPresets = response.data.presets;
                    updatePresetDropdown(savedPresets);
                    $('#preset-name').val('');
                } else {
                    showNotification(InitMangaCrawler.i18n.preset_save_error + ': ' + response.data, 'error');
                }
            },
            error: function() {
                showNotification(InitMangaCrawler.i18n.preset_save_error, 'error');
            },
            complete: function() {
                $button.text(originalText).prop('disabled', false);
            }
        });
    });

    // Load Preset
    $('#load-preset').on('click', function() {
        const selectedPreset = $('#preset-selector').val();
        
        if (!selectedPreset) {
            alert(InitMangaCrawler.i18n.preset_select_required);
            return;
        }

        if (savedPresets[selectedPreset]) {
            loadFormData(savedPresets[selectedPreset]);
            showNotification(InitMangaCrawler.i18n.preset_loaded);
        }
    });

    // Delete Preset
    $('#delete-preset').on('click', function() {
        const selectedPreset = $('#preset-selector').val();
        
        if (!selectedPreset) {
            alert(InitMangaCrawler.i18n.preset_select_required);
            return;
        }

        if (!confirm(InitMangaCrawler.i18n.preset_delete_confirm)) {
            return;
        }

        const $button = $(this);
        const originalText = $button.text();
        
        $button.text('Deleting...').prop('disabled', true);

        $.ajax({
            url: InitMangaCrawler.ajax_url,
            type: 'POST',
            data: {
                action: 'init_manga_delete_preset',
                nonce: InitMangaCrawler.nonce,
                preset_name: selectedPreset
            },
            success: function(response) {
                if (response.success) {
                    showNotification(response.data.message);
                    savedPresets = response.data.presets;
                    updatePresetDropdown(savedPresets);
                    $('#preset-selector').val('');
                } else {
                    showNotification(InitMangaCrawler.i18n.preset_delete_error + ': ' + response.data, 'error');
                }
            },
            error: function() {
                showNotification(InitMangaCrawler.i18n.preset_delete_error, 'error');
            },
            complete: function() {
                $button.text(originalText).prop('disabled', false);
            }
        });
    });

    // Auto-fill preset name when selector changes
    $('#preset-selector').on('change', function() {
        if ($(this).val()) {
            $('#preset-name').val($(this).val());
        }
    });

    // Export Presets
    $('#export-presets').on('click', function() {
        const dataStr = JSON.stringify(savedPresets, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
        
        const exportFileDefaultName = 'manga-crawler-presets.json';
        
        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
        
        showNotification('Presets exported successfully!');
    });

    // Import Presets
    $('#import-presets-btn').on('click', function() {
        $('#import-presets').click();
    });

    $('#import-presets').on('change', function(e) {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const importedPresets = JSON.parse(e.target.result);
                
                // Merge with existing presets
                Object.assign(savedPresets, importedPresets);
                
                // Update dropdown
                updatePresetDropdown(savedPresets);
                
                // Save to database
                $.ajax({
                    url: InitMangaCrawler.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'init_manga_import_presets',
                        nonce: InitMangaCrawler.nonce,
                        presets_data: JSON.stringify(savedPresets)
                    },
                    success: function(response) {
                        if (response.success) {
                            showNotification(InitMangaCrawler.i18n.presets_imported);
                        } else {
                            showNotification(InitMangaCrawler.i18n.import_error, 'error');
                        }
                    },
                    error: function() {
                        showNotification(InitMangaCrawler.i18n.import_error, 'error');
                    }
                });
            } catch (e) {
                showNotification(InitMangaCrawler.i18n.invalid_json, 'error');
            }
        };
        reader.readAsText(file);
        
        // Reset file input
        $(this).val('');
    });

    // Keyboard Shortcuts for Quick Loading
    $(document).on('keydown', function(e) {
        // Ctrl/Cmd + Number keys to quick-load presets
        if ((e.ctrlKey || e.metaKey) && e.which >= 49 && e.which <= 57) {
            const presetIndex = e.which - 49; // 0-8 for keys 1-9
            const presetNames = Object.keys(savedPresets);
            
            if (presetNames[presetIndex]) {
                $('#preset-selector').val(presetNames[presetIndex]);
                loadFormData(savedPresets[presetNames[presetIndex]]);
                e.preventDefault();
                
                showNotification('Loaded: ' + presetNames[presetIndex]);
            }
        }
    });

    // Auto-save current form state to localStorage for recovery
    function autoSaveFormState() {
        const formData = getAllFormData();
        localStorage.setItem('init_manga_crawler_autosave', JSON.stringify(formData));
    }

    function loadAutoSavedState() {
        const saved = localStorage.getItem('init_manga_crawler_autosave');
        if (saved) {
            try {
                const formData = JSON.parse(saved);
                // Only load if form is relatively empty
                const isEmpty = !$('#selector_title').val() && !$('#selector_description').val();
                if (isEmpty) {
                    loadFormData(formData);
                    showNotification('Auto-restored previous session', 'info');
                }
            } catch (e) {
                // Ignore parsing errors
            }
        }
    }

    // Auto-save on form changes (debounced)
    let autoSaveTimeout;
    $('#init-manga-crawler-form input, #init-manga-crawler-form textarea').on('input change', function() {
        clearTimeout(autoSaveTimeout);
        autoSaveTimeout = setTimeout(autoSaveFormState, 1000);
    });

    // Load auto-saved state on page load
    loadAutoSavedState();

    // Custom notification styles for different types
    function showNotification(message, type = 'success') {
        let bgColor, icon;
        
        switch(type) {
            case 'success':
                bgColor = '#4CAF50';
                icon = '✅';
                break;
            case 'error':
                bgColor = '#f44336';
                icon = '❌';
                break;
            case 'info':
                bgColor = '#2196F3';
                icon = 'ℹ️';
                break;
            default:
                bgColor = '#4CAF50';
                icon = '✅';
        }
        
        const $notification = $('<div style="position: fixed; top: 20px; right: 20px; background: ' + bgColor + '; color: white; padding: 12px 20px; border-radius: 6px; z-index: 9999; box-shadow: 0 4px 6px rgba(0,0,0,0.1); font-weight: 500;">' + icon + ' ' + message + '</div>');
        $('body').append($notification);
        
        setTimeout(function() {
            $notification.fadeOut(400, function() {
                $(this).remove();
            });
        }, 3000);
    }
});
