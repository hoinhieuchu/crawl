jQuery(document).ready(function ($) {
	const i18n = InitMangaCrawler.i18n;

	const $form = $('#init-manga-crawler-form');
	const $logBox = $('#im-crawl-log');
	const $logList = $('#im-crawl-log-list');
	const $startBtn = $('#im-crawl-button');
	const storageKey = 'init_manga_crawler_form_data';

	// Hàng đợi các URL truyện sẽ được crawl
	let mangaUrlQueue = []; 
	
	let chapterQueue = [];
	let currentPostId = 0;
	let successCount = 0;
	let failCount = 0;
	let startTime = 0;

	// === Restore form data ===
	const saved = localStorage.getItem(storageKey);
	if (saved) {
		try {
			const data = JSON.parse(saved);
			for (const key in data) {
				const $field = $form.find(`[name="${key}"]`);
				if ($field.length) {
					if ($field.attr('type') === 'radio') {
						$form.find(`[name="${key}"][value="${data[key]}"]`).prop('checked', true);
					} else {
						$field.val(data[key]);
					}
				} else {
					// Handle non-named fields
					if (key === 'preprocess_url') $('#preprocess_url').val(data[key]);
					if (key === 'preprocess_selector') $('#preprocess_selector').val(data[key]);
				}
			}
		} catch (e) {
			console.warn('[Init Crawler] Could not parse saved data:', e);
		}
	}

	// === Auto-save form data ===
	let timeout;
	$form.on('input change', 'input, textarea, select', function () {
		clearTimeout(timeout);
		timeout = setTimeout(() => {
			const values = {};
			$form.serializeArray().forEach(item => values[item.name] = item.value);

			// Save extra fields manually
			values['preprocess_url'] = $('#preprocess_url').val();
			values['preprocess_selector'] = $('#preprocess_selector').val();

			localStorage.setItem(storageKey, JSON.stringify(values));
		}, 300);
	});

	// === Logging UI + console
	function log(msg, type = 'normal') {
		$logBox.show();
		const $li = $('<li>').html(msg);
		if (type === 'success') $li.css('color', 'green');
		if (type === 'error') $li.css('color', 'red');
		$logList.append($li);
		$logBox.scrollTop($logBox[0].scrollHeight);
	}

	$('#preprocess-fetch').on('click', function () {
		const $btn = $(this);
		const url = $('#preprocess_url').val().trim();
		const selector = $('#preprocess_selector').val().trim();

		if (!url || !selector) {
			log(i18n.missing_input, 'error');
			return;
		}

		$btn.prop('disabled', true).text(i18n.fetching_links);

		$.post(InitMangaCrawler.ajax_url, {
			action: 'init_manga_crawler_extract_links',
			url: url,
			selector: selector
		}, function (response) {
			if (response.success && Array.isArray(response.data.urls)) {
				const result = response.data.urls.join('\n');
				$('#crawl_link').val(result);

				log(i18n.fetch_links_done.replace('%d', `<strong>${response.data.urls.length}</strong>`), 'success');

				const values = {};
				$form.serializeArray().forEach(item => values[item.name] = item.value);
				values['preprocess_url'] = $('#preprocess_url').val();
				values['preprocess_selector'] = $('#preprocess_selector').val();
				values['crawl_link'] = result; // override textarea content
				localStorage.setItem(storageKey, JSON.stringify(values));

			} else {
				const msg = response.data?.message || i18n.unknown_error;
				log(i18n.fetch_error_prefix + msg, 'error');
			}
		}).fail(function () {
			log(i18n.fetch_failed, 'error');
		}).always(function () {
			$btn.prop('disabled', false).text(i18n.fetch_links);
		});
	});


	// === Start crawling
	$startBtn.on('click', function () {
		const urls = $('#crawl_link').val().split('\n').map(url => url.trim()).filter(url => url);

		if (urls.length === 0) {
			log(i18n.no_url_error, 'error');
			return;
		}

		mangaUrlQueue = urls;
		$logList.empty();
		successCount = 0;
		failCount = 0;
		startTime = performance.now();

		// Sử dụng i18n, thay thế placeholder %d bằng số lượng URL
		log(i18n.batch_start.replace('%d', `<strong>${mangaUrlQueue.length}</strong>`));
		$startBtn.prop('disabled', true).text(i18n.crawling_text);

		processNextManga();
	});
	
	/**
	 * Bắt đầu xử lý truyện tiếp theo trong hàng đợi.
	 * Đây là hàm quản lý vòng lặp chính.
	 */
	function processNextManga() {
		if (mangaUrlQueue.length === 0) {
			const duration = ((performance.now() - startTime) / 1000).toFixed(1);
			log(`<strong>${i18n.batch_complete}</strong>`, 'success');
			log(i18n.total_time.replace('%s', `<strong>${duration}</strong>`));
			$startBtn.prop('disabled', false).text(i18n.start_text);
			return;
		}
		const nextUrl = mangaUrlQueue.shift();
		crawlSingleManga(nextUrl);
	}

	/**
	 * Gửi yêu cầu AJAX để crawl thông tin của MỘT truyện.
	 * @param {string} mangaUrl - URL của truyện cần crawl.
	 */
	function crawlSingleManga(mangaUrl) {
		log(i18n.processing_start.replace('%s', `<strong>${mangaUrl}</strong>`));

		const otherFormData = $form.serializeArray().filter(item => item.name !== 'crawl_link');
		const payload = {
			action: 'init_manga_crawler_run',
			nonce: InitMangaCrawler.nonce
		};
		otherFormData.forEach(item => payload[item.name] = item.value);
		payload.crawl_link = mangaUrl;

		$.post(InitMangaCrawler.ajax_url, payload, function (response) {
			if (response.success) {
				const res = response.data;
				currentPostId = res.post_id;
				chapterQueue = res.chapters || [];
				chapterQueue = ensureChaptersAscending(chapterQueue);

				log(i18n.manga_info_ok.replace('%d', `<strong>${currentPostId}</strong>`).replace('%s', `<strong>${res.title}</strong>`), 'success');
				log(i18n.chapters_found.replace('%d', `<strong>${chapterQueue.length}</strong>`));

				processNextChapter();
			} else {
				const message = response.data?.message || i18n.unknown_error;
				log(i18n.manga_info_error.replace('%s', message), 'error');
				console.error('[Init Crawler] Manga Error:', response);
				processNextManga();
			}
		}).fail(function () {
			log(i18n.ajax_manga_error, 'error');
			processNextManga();
		});
	}

	/**
	 * Xử lý từng chương của truyện HIỆN TẠI.
	 * Khi hết chương, nó sẽ gọi hàm để xử lý truyện TIẾP THEO.
	 */
	function processNextChapter() {
		if (chapterQueue.length === 0) {
			log(i18n.chapters_complete.replace('%d', currentPostId), 'success');
			processNextManga();
			return;
		}

		const chapter = chapterQueue.shift();
		const number = extractChapterNumber(chapter.name);

		const payload = {
			action: 'init_manga_crawler_add_chapter',
			nonce: InitMangaCrawler.nonce,
			post_id: currentPostId,
			number: number,
			url: chapter.url,
			content_selector: $('#selector_content').val()
		};

		log(i18n.crawling_chapter.replace('%s', `<strong>${chapter.name}</strong>`));

		$.post(InitMangaCrawler.ajax_url, payload, function (resp) {
			if (resp.success) {
				successCount++;
				const status = resp.data.status;
				if (status === 'already_exists') {
					log(i18n.chapter_skipped.replace('%s', `<strong>${number}</strong>`));
				} else {
					log(i18n.chapter_saved.replace('%s', `<strong>${number}</strong>`), 'success');
				}
			} else {
				failCount++;
				const message = resp.data?.message || i18n.unknown_error;
				log(i18n.chapter_error.replace('%s', `<strong>${number}</strong>`).replace('%s', message), 'error');
				console.error('[Init Crawler] Chapter error:', resp);
			}
			processNextChapter();
		}).fail(function () {
			failCount++;
			log(i18n.ajax_chapter_error.replace('%s', `<strong>${number}</strong>`), 'error');
			processNextChapter();
		});
	}

	// === Hàm detect và đảo ngược nếu cần ===
	function ensureChaptersAscending(chapterQueue) {
		if (chapterQueue.length < 2) return;
		
		// Trích xuất số chapter để so sánh
		const getChapterNum = (name) => {
			const match = name.match(/(\d+([.,]?\d+)?)/);
			return match ? parseFloat(match[1].replace(',', '.')) : null;
		};
		
		// Tìm chapters có số thực sự (không phải ngoại truyện)
		const numberedChapters = chapterQueue
			.map((chapter, index) => ({
				...chapter,
				originalIndex: index,
				number: getChapterNum(chapter.name)
			}))
			.filter(chapter => chapter.number !== null);
		
		if (numberedChapters.length < 2) return;
		
		// So sánh chapter có số đầu tiên và cuối cùng
		const firstNumbered = numberedChapters[0];
		const lastNumbered = numberedChapters[numberedChapters.length - 1];
		
		// Nếu đang giảm dần thì reverse
		if (firstNumbered.number > lastNumbered.number) {
			chapterQueue.reverse();
		}
		return chapterQueue;
	}

	// === Hàm trích xuất số chương ===
	let lastChapterNumber = 0; // Biến lưu số chương cuối cùng
	
	function extractChapterNumber(name) {
		const nameLower = name.toLowerCase();
		
		// Kiểm tra nếu là ngoại truyện hoặc phiên ngoại
		if (nameLower.includes('ngoại truyện') || nameLower.includes('phiên ngoại')) {
			return lastChapterNumber + 0.5;
		}
		
		const match = name.match(/(\d+([.,]?\d+)?)/);
		const chapterNum = match ? parseFloat(match[1].replace(',', '.')) : 0;
		
		// Cập nhật số chương cuối cùng nếu không phải ngoại truyện
		if (chapterNum > 0) {
			lastChapterNumber = chapterNum;
		}
		
		return chapterNum;
	}
});
